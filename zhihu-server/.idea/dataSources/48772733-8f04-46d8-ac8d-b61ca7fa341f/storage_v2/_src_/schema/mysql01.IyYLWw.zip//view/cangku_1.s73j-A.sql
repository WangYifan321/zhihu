create definer = root@`%` view cangku_1 as
select `mysql01`.`book`.`book_id`     AS `book_id`,
       `mysql01`.`book`.`name`        AS `name`,
       `mysql01`.`book`.`type`        AS `type`,
       `mysql01`.`cangku`.`cangku_id` AS `cangku_id`,
       `mysql01`.`book`.`cangkuname`  AS `cangkuname`,
       `mysql01`.`cangku`.`location`  AS `location`,
       `mysql01`.`cangku`.`phone`     AS `phone`
from `mysql01`.`book`
         join `mysql01`.`cangku`
where ((`mysql01`.`cangku`.`num` > 0) and (`mysql01`.`book`.`cangkuname` = `mysql01`.`cangku`.`name`));

