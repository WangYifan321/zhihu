create definer = root@`%` view book_sale as
select `mysql01`.`vipuser`.`vip_id`   AS `vip_id`,
       `mysql01`.`vipuser`.`name`     AS `name`,
       `mysql01`.`tiaomu`.`username`  AS `username`,
       `mysql01`.`vipuser`.`phone`    AS `phone`,
       `mysql01`.`vipuser`.`address`  AS `address`,
       `mysql01`.`vipuser`.`sex`      AS `sex`,
       `mysql01`.`book`.`book_id`     AS `book_id`,
       `mysql01`.`tiaomu`.`book_name` AS `book_name`,
       `mysql01`.`book`.`price`       AS `price`,
       `mysql01`.`book`.`cangkuname`  AS `cangkuname`,
       `mysql01`.`book`.`press`       AS `press`,
       `mysql01`.`book`.`author`      AS `author`,
       `mysql01`.`book`.`type`        AS `type`
from `mysql01`.`tiaomu`
         join `mysql01`.`book`
         join `mysql01`.`vipuser`
where ((`mysql01`.`tiaomu`.`book_name` = `mysql01`.`book`.`name`) and
       (`mysql01`.`tiaomu`.`username` = `mysql01`.`vipuser`.`username`));

-- comment on column book_sale.name not supported: unique

