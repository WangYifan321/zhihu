create
    definer = root@`%` procedure deletevip(IN vip_id1 int, IN book_id1 int)
BEGIN
	declare username1 varchar(30);
	declare name1 varchar(30);
	if vip_id1>0 then
	select name into name1 
	 from vipuser where vip_id = vip_id1;
	 select username into username1
	 from vip_user where vip_id = vip_id1;
	 delete from comment 
	   where vip_id = vip_id1;
	 delete from dingdan
	   where username = name1;
		 delete from fahuo
		 where vip_name = name1;
		 delete from tiaomu
		where username = username1;
		delete from vipuser
		where vip_id = vip_id1;
		end if;
		if book_id1!=0 then
		delete from book
		 where book_id = book_id1;
	 delete from comment
	 where book_id = book_id1;
	 end if;
END;

