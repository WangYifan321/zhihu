create definer = root@`%` view cangku_1 as
select `bookshop`.`book`.`book_id`     AS `book_id`,
       `bookshop`.`book`.`name`        AS `name`,
       `bookshop`.`book`.`type`        AS `type`,
       `bookshop`.`cangku`.`cangku_id` AS `cangku_id`,
       `bookshop`.`book`.`cangkuname`  AS `cangkuname`,
       `bookshop`.`cangku`.`location`  AS `location`,
       `bookshop`.`cangku`.`phone`     AS `phone`
from `bookshop`.`book`
         join `bookshop`.`cangku`
where ((`bookshop`.`cangku`.`num` > 0) and (`bookshop`.`book`.`cangkuname` = `bookshop`.`cangku`.`name`));

