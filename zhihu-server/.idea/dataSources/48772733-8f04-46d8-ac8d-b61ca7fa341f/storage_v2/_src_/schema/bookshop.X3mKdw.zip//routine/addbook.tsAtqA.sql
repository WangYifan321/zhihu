create
    definer = root@`%` procedure addbook(IN book_cangku_name varchar(255), IN book_booktype_name varchar(255),
                                         IN book_press varchar(23))
BEGIN
	 declare num int;
	 select count(*) 
	   into num 
		   from cangku 
			   where name = book_cangku_name;
	 if num = 0 then
	 insert into cangku (name) 
	    values (book_cangku_name);
	 end if; 
	 select count(*) 
	   into num 
		   from booktype 
			   where name = book_booktype_name;
	 if num = 0 then
	 insert into booktype (name) 
	   values (book_booktype_name);
	 end if;
   	 select count(*) into num 
		   from press 
			   where name = book_press;
	 if num = 0 then
	 insert into press (name) 
	   values (book_press);
	 end if;
END;

