create
    definer = root@`%` procedure submit(IN vipname varchar(200))
BEGIN
	declare summoney int;
	declare vip int;
	declare num int;
	declare uname varchar(40); 
	select sum(money) 
	  into summoney 
	    from tiaomu 
	      where username = vipname and state = 1;
	select vip_id 
	  into vip 
	    from vipuser 
	      where username = vipname;
		select name
		  into uname
			  from vipuser  
				  where username = vipname;
  delete from tiaomu 
		  where username = vipname and state =1;
   insert into dingdan (vip_id,ying_money,shi_money,username) 
	   values (vip,summoney,summoney,uname);
	 END;

