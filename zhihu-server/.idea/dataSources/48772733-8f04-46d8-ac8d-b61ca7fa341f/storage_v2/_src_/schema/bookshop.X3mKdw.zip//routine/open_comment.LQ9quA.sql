create
    definer = root@`%` procedure open_comment(IN tiaomu_id1 int, IN vip_id1 int)
BEGIN
	declare booknum int;
	declare vipnum int;
	declare booksum int;
	declare book_id1 int;
	declare book_name1 varchar(30);
	select book_name into book_name1
	from tiaomu
	where tiaomu_id = tiaomu_id1;
	 select book_id into book_id1 
	 from book where name = book_name1;
	select count(*) 
	    into booknum
	  from book where book_id = book_id1; 
	select count(*) 
	   into vipnum
		   from vipuser where vip_id = vip_id1;
 if booknum!=0 and vipnum!=0 then
   insert into comment (vip_id,book_id)
	  values (vip_id1,book_id1);
		end if;
	if booknum=0 then
	delete from comment 
	  where book_id = book_id1 and vip_id = vip_id1;
		end if;
			if vipnum=0 then
	delete from comment 
	  where book_id = book_id1 and vip_id = vip_id1;
		end if;
		select num into booksum 
		  from book
			 where book_id = book_id1;
			 if booksum >1 then
	  update book set num = booksum-1
		 where book_id = book_id1;
		 end if;
END;

